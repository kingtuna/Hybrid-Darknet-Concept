#!/bin/bash
/usr/bin/python /root/python/daily_summary.py
/usr/bin/python /root/python/transmission_test.py
